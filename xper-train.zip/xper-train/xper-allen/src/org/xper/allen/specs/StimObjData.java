package org.xper.allen.specs;

import com.thoughtworks.xstream.XStream;

public class StimObjData {
	long id;
	String spec;
	String data;
	
	public long get_id() {
		return id;
	}
	public void set_id(long id) {
		this.id = id;
	}
	public String get_spec() {
		return spec;
	}
	public void set_spec(String spec) {
		this.spec = spec;
	}
	public String get_data() {
		return data;
	}
	public void set_data(String data) {
		this.data = data;
	}
	

}
