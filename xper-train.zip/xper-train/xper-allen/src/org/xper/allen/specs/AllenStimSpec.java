package org.xper.allen.specs;

/**
 * Fields are just an id and xml string. 
 * @author Allen Chen
 *
 */
public class AllenStimSpec {
	long id;
	String spec;
}
