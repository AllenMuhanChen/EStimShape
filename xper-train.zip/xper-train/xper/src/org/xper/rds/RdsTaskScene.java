package org.xper.rds;

import org.xper.drawing.AbstractTaskScene;
import org.xper.drawing.Context;
import org.xper.experiment.ExperimentTask;

public class RdsTaskScene extends AbstractTaskScene {

	@Override
	public void drawStimulus(Context context) {
	}

	@Override
	public void setTask(ExperimentTask task) {
	}

}
