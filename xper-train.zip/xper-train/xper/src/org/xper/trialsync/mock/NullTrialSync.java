package org.xper.trialsync.mock;

import org.xper.trialsync.TrialSync;

public class NullTrialSync implements TrialSync {

	public void startTrialSyncPulse() {
		// TODO Auto-generated method stub
		
	}

	public void stopTrialSyncPulse() {
		// TODO Auto-generated method stub
		
	}

}
