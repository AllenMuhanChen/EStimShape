package org.xper.trialsync;

public interface TrialSync {
	public void startTrialSyncPulse();
	public void stopTrialSyncPulse();
}
