package org.xper.console;

public interface CommandListener {
	public void experimentResume();
	public void experimentPause();
	public void experimentStop();
}
