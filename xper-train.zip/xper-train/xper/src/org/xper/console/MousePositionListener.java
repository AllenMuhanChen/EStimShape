package org.xper.console;

public interface MousePositionListener {
	/**
	 * 
	 * @param x window coordinate
	 * @param y
	 */
	public void mousePosition(int x, int y);
}
