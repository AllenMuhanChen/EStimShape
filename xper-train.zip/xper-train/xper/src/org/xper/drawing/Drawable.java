package org.xper.drawing;



public interface Drawable {
	public void draw (Context context);
}
