package org.xper.acq.device;


public interface AnalogOutDevice {

	public abstract void write(double[] data);

}