package org.xper.mockxper;

public interface MockSpikeGenerator {
	public double getSpikeRate (long taskId);
}
